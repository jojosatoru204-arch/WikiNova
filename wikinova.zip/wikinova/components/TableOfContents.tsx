"use client";

import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { List } from "lucide-react";

interface Heading { id: string; text: string; level: number; }

export function TableOfContents() {
  const [headings, setHeadings] = useState<Heading[]>([]);
  const [active, setActive] = useState("");

  useEffect(() => {
    const article = document.querySelector("article");
    if (!article) return;

    const els = Array.from(article.querySelectorAll("h2, h3")) as HTMLHeadingElement[];
    const items = els.map((el) => {
      if (!el.id) {
        el.id =
          el.textContent?.toLowerCase().replace(/\s+/g, "-").replace(/[^\w-]/g, "") || "";
      }
      return {
        id: el.id,
        text: el.textContent || "",
        level: el.tagName === "H2" ? 2 : 3,
      };
    });
    setHeadings(items);

    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) setActive(entry.target.id);
        });
      },
      { rootMargin: "-80px 0px -70% 0px" }
    );
    els.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, []);

  if (headings.length === 0) return null;

  return (
    <div className="sticky top-24 max-h-[calc(100vh-8rem)] overflow-y-auto">
      <h3 className="text-xs font-semibold text-neutral-500 uppercase mb-3 flex items-center gap-2">
        <List className="w-3.5 h-3.5" /> Mục lục
      </h3>
      <nav className="space-y-1 border-l-2 border-neutral-200 dark:border-neutral-800">
        {headings.map((h) => (
          <a
            key={h.id}
            href={`#${h.id}`}
            className={cn(
              "block py-1.5 text-sm transition-colors border-l-2 -ml-[2px]",
              h.level === 2 ? "pl-3" : "pl-6 text-xs",
              active === h.id
                ? "border-blue-500 text-blue-600 dark:text-blue-400 font-medium"
                : "border-transparent text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-neutral-200"
            )}
          >
            {h.text}
          </a>
        ))}
      </nav>
    </div>
  );
}