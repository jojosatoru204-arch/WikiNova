"use client";

import { useEffect, useRef } from "react";
import { useTheme } from "next-themes";

export function Comments({ term }: { term: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const { theme } = useTheme();

  useEffect(() => {
    if (!ref.current) return;
    ref.current.innerHTML = "";

    const script = document.createElement("script");
    script.src = "https://giscus.app/client.js";
    script.setAttribute("data-repo", "yourname/wikinova");
    script.setAttribute("data-repo-id", "R_xxx");
    script.setAttribute("data-category", "Comments");
    script.setAttribute("data-category-id", "DIC_xxx");
    script.setAttribute("data-mapping", "specific");
    script.setAttribute("data-term", term);
    script.setAttribute("data-reactions-enabled", "1");
    script.setAttribute("data-emit-metadata", "0");
    script.setAttribute("data-theme", theme === "dark" ? "dark" : "light");
    script.setAttribute("data-lang", "vi");
    script.crossOrigin = "anonymous";
    script.async = true;

    ref.current.appendChild(script);
  }, [term, theme]);

  return (
    <div className="mt-16 pt-8 border-t border-neutral-200 dark:border-neutral-800">
      <h2 className="text-xl font-bold mb-6">💬 Thảo luận</h2>
      <div ref={ref} />
    </div>
  );
}