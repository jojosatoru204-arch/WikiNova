"use client";

import { Command } from "cmdk";
import { useEffect, useState } from "react";
import { Search, FileText, Loader2, ArrowRight } from "lucide-react";
import { useRouter } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";

interface SearchResult {
  title: string;
  snippet: string;
  slug: string;
}

export function CommandPalette() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === "k") {
        e.preventDefault();
        setOpen((v) => !v);
      }
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, []);

  useEffect(() => {
    if (query.length < 2) {
      setResults([]);
      return;
    }
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const data = await res.json();
        setResults(data.results);
      } finally {
        setLoading(false);
      }
    }, 300);
    return () => clearTimeout(t);
  }, [query]);

  const go = (slug: string) => {
    setOpen(false);
    setQuery("");
    router.push(`/bai-viet/${slug}`);
  };

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          className="fixed inset-0 z-[100] bg-black/50 backdrop-blur-sm grid place-items-start pt-[15vh] px-4"
          onClick={() => setOpen(false)}
        >
          <motion.div
            initial={{ scale: 0.95, y: -10 }}
            animate={{ scale: 1, y: 0 }}
            exit={{ scale: 0.95, y: -10 }}
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-xl bg-white dark:bg-neutral-900 rounded-2xl shadow-2xl border border-neutral-200 dark:border-neutral-800 overflow-hidden"
          >
            <Command shouldFilter={false} className="w-full">
              <div className="flex items-center gap-3 px-4 border-b border-neutral-200 dark:border-neutral-800">
                <Search className="w-5 h-5 text-neutral-400" />
                <Command.Input
                  value={query}
                  onValueChange={setQuery}
                  placeholder="Tìm bài viết Wikipedia..."
                  className="flex-1 h-14 bg-transparent outline-none text-base"
                  autoFocus
                />
                {loading && <Loader2 className="w-4 h-4 animate-spin text-blue-500" />}
                <kbd className="text-xs px-2 py-1 rounded bg-neutral-100 dark:bg-neutral-800">
                  ESC
                </kbd>
              </div>

              <Command.List className="max-h-96 overflow-y-auto p-2">
                {results.length === 0 && query.length >= 2 && !loading && (
                  <div className="text-center py-8 text-sm text-neutral-500">
                    Không tìm thấy kết quả cho "{query}"
                  </div>
                )}
                {query.length < 2 && (
                  <div className="text-center py-8 text-sm text-neutral-500">
                    Nhập ít nhất 2 ký tự để tìm kiếm
                  </div>
                )}
                {results.map((r) => (
                  <Command.Item
                    key={r.slug}
                    value={r.slug}
                    onSelect={() => go(r.slug)}
                    className="flex items-start gap-3 px-3 py-3 rounded-lg cursor-pointer hover:bg-neutral-100 dark:hover:bg-neutral-800 data-[selected=true]:bg-neutral-100 dark:data-[selected=true]:bg-neutral-800"
                  >
                    <FileText className="w-4 h-4 mt-1 text-blue-500 shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium truncate">{r.title}</p>
                      <p className="text-xs text-neutral-500 line-clamp-1">{r.snippet}</p>
                    </div>
                    <ArrowRight className="w-4 h-4 text-neutral-400" />
                  </Command.Item>
                ))}
              </Command.List>
            </Command>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}