"use client";

import { useState } from "react";
import {
  History, FlaskConical, Palette, Cpu, Music, Globe, Trophy,
  GraduationCap, Sparkles, Menu, X,
} from "lucide-react";
import { cn } from "@/lib/utils";

const CATEGORIES = [
  { name: "Lịch sử", icon: History, color: "text-amber-500" },
  { name: "Khoa học", icon: FlaskConical, color: "text-blue-500" },
  { name: "Văn hóa", icon: Palette, color: "text-pink-500" },
  { name: "Công nghệ", icon: Cpu, color: "text-purple-500" },
  { name: "Nghệ thuật", icon: Music, color: "text-rose-500" },
  { name: "Địa lý", icon: Globe, color: "text-green-500" },
  { name: "Thể thao", icon: Trophy, color: "text-orange-500" },
  { name: "Giáo dục", icon: GraduationCap, color: "text-cyan-500" },
];

export function Sidebar() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        onClick={() => setOpen(!open)}
        className="lg:hidden fixed bottom-6 right-6 z-40 w-14 h-14 rounded-full bg-gradient-to-r from-blue-600 to-purple-600 text-white shadow-xl grid place-items-center"
      >
        {open ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
      </button>

      <aside
        className={cn(
          "fixed lg:sticky top-0 lg:top-16 left-0 z-30 h-screen lg:h-[calc(100vh-4rem)] w-64 bg-white dark:bg-neutral-950 border-r border-neutral-200 dark:border-neutral-800 p-4 overflow-y-auto transition-transform",
          open ? "translate-x-0" : "-translate-x-full lg:translate-x-0"
        )}
      >
        <div className="mb-6">
          <h3 className="text-xs font-semibold text-neutral-500 uppercase tracking-wider mb-3 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5" /> Danh mục
          </h3>
          <nav className="space-y-1">
            {CATEGORIES.map(({ name, icon: Icon, color }) => (
              <a
                key={name}
                href={`/danh-muc/${encodeURIComponent(name)}`}
                className="flex items-center gap-3 px-3 py-2 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-900 text-sm font-medium transition-colors"
              >
                <Icon className={cn("w-4 h-4", color)} />
                {name}
              </a>
            ))}
          </nav>
        </div>

        <div className="pt-4 border-t border-neutral-200 dark:border-neutral-800">
          <a
            href="/ngau-nhien"
            className="block px-3 py-2 rounded-lg bg-gradient-to-r from-blue-500/10 to-purple-500/10 text-sm font-medium text-center hover:from-blue-500/20 hover:to-purple-500/20 transition"
          >
            🎲 Bài viết ngẫu nhiên
          </a>
        </div>
      </aside>
    </>
  );
}