"use client";

import { motion } from "framer-motion";
import { RefreshCw, CheckCircle2 } from "lucide-react";
import { timeAgo } from "@/lib/utils";

interface Props {
  lastUpdate: Date;
  isFetching: boolean;
  newCount: number;
}

export function LiveUpdateBanner({ lastUpdate, isFetching, newCount }: Props) {
  return (
    <motion.div
      initial={{ opacity: 0, y: -10 }}
      animate={{ opacity: 1, y: 0 }}
      className="flex items-center justify-between rounded-xl bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-950/30 dark:to-purple-950/30 border border-blue-200 dark:border-blue-900 px-4 py-3 mb-6"
    >
      <div className="flex items-center gap-3">
        {isFetching ? (
          <RefreshCw className="w-4 h-4 text-blue-600 animate-spin" />
        ) : (
          <CheckCircle2 className="w-4 h-4 text-green-600" />
        )}
        <div>
          <p className="text-sm font-medium">
            {isFetching
              ? "Đang cập nhật thông tin mới..."
              : newCount > 0
              ? `🆕 ${newCount} bài viết vừa được cập nhật!`
              : "Nội dung đã là mới nhất"}
          </p>
          <p className="text-xs text-neutral-500">
            Cập nhật lần cuối: {timeAgo(lastUpdate)} · Tự động làm mới mỗi 60s
          </p>
        </div>
      </div>
    </motion.div>
  );
}