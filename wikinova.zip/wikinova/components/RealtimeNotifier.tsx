"use client";

import { useEffect, useRef } from "react";
import { toast } from "sonner";
import { useQuery } from "@tanstack/react-query";

export function RealtimeNotifier() {
  const prevIds = useRef<Set<string>>(new Set());

  const { data } = useQuery({
    queryKey: ["articles"],
    queryFn: async () => {
      const r = await fetch("/api/articles");
      return r.json();
    },
    refetchInterval: 60_000,
    refetchIntervalInBackground: true,
  });

  useEffect(() => {
    if (!data?.articles) return;
    const current = new Set<string>(data.articles.map((a: any) => a.id));
    if (prevIds.current.size > 0) {
      const newOnes = [...current].filter((id) => !prevIds.current.has(id));
      if (newOnes.length > 0) {
        toast.success(`🆕 ${newOnes.length} bài viết mới vừa được cập nhật!`, {
          description: "Nhấn để xem bài mới nhất",
          action: {
            label: "Xem",
            onClick: () => window.scrollTo({ top: 0, behavior: "smooth" }),
          },
          duration: 8000,
        });
      }
    }
    prevIds.current = current;
  }, [data]);

  return null;
}