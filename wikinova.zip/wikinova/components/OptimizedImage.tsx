"use client";

import Image from "next/image";

interface Props {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  priority?: boolean;
  className?: string;
}

export function OptimizedImage({
  src,
  alt,
  width = 800,
  height = 500,
  priority,
  className,
}: Props) {
  if (!src) return null;

  if (src.includes("wikimedia.org")) {
    return (
      <Image
        src={src}
        alt={alt}
        width={width}
        height={height}
        priority={priority}
        className={className}
        sizes="(max-width: 768px) 100vw, 800px"
      />
    );
  }

  const cloudName = process.env.NEXT_PUBLIC_CLOUDINARY_CLOUD_NAME;
  const optimized = cloudName
    ? `https://res.cloudinary.com/${cloudName}/image/fetch/f_auto,q_auto,w_${width}/${encodeURIComponent(src)}`
    : src;

  return (
    <Image
      src={optimized}
      alt={alt}
      width={width}
      height={height}
      priority={priority}
      className={className}
      unoptimized
    />
  );
}