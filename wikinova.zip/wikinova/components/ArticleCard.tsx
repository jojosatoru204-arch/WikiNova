"use client";

import { motion } from "framer-motion";
import { Eye, Clock, Sparkles } from "lucide-react";
import { WikiArticle } from "@/lib/types";
import { timeAgo } from "@/lib/utils";
import { OptimizedImage } from "@/components/OptimizedImage";

interface Props {
  article: WikiArticle;
  isNew?: boolean;
  index: number;
}

export function ArticleCard({ article, isNew, index }: Props) {
  return (
    <motion.a
      href={`/bai-viet/${article.slug}`}
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.05 }}
      whileHover={{ y: -4 }}
      className="group relative rounded-2xl border border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900 overflow-hidden hover:shadow-xl hover:border-blue-300 dark:hover:border-blue-700 transition-all"
    >
      {isNew && (
        <div className="absolute top-3 right-3 z-10 flex items-center gap-1 px-2 py-1 rounded-full bg-green-500 text-white text-xs font-medium shadow-lg animate-pulse">
          <Sparkles className="w-3 h-3" /> Mới
        </div>
      )}

      {article.thumbnail ? (
        <div className="aspect-[16/10] relative overflow-hidden bg-neutral-100 dark:bg-neutral-800">
          <OptimizedImage
            src={article.thumbnail}
            alt={article.title}
            width={400}
            height={250}
            className="object-cover w-full h-full group-hover:scale-105 transition-transform duration-500"
          />
        </div>
      ) : (
        <div className="aspect-[16/10] bg-gradient-to-br from-blue-500/20 to-purple-500/20 grid place-items-center">
          <Sparkles className="w-12 h-12 text-blue-500/50" />
        </div>
      )}

      <div className="p-5">
        <div className="flex items-center gap-2 mb-2">
          <span className="text-xs px-2 py-0.5 rounded-full bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-300 font-medium">
            {article.category}
          </span>
        </div>
        <h3 className="font-bold text-lg mb-2 line-clamp-2 group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
          {article.title}
        </h3>
        <p className="text-sm text-neutral-600 dark:text-neutral-400 line-clamp-3 mb-4">
          {article.extract}
        </p>
        <div className="flex items-center gap-4 text-xs text-neutral-500">
          <span className="flex items-center gap-1">
            <Eye className="w-3.5 h-3.5" />
            {article.views.toLocaleString("vi-VN")}
          </span>
          <span className="flex items-center gap-1">
            <Clock className="w-3.5 h-3.5" />
            {timeAgo(article.updatedAt)}
          </span>
        </div>
      </div>
    </motion.a>
  );
}