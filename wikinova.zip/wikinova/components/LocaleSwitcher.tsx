"use client";

import { useLocale } from "next-intl";
import { useRouter, usePathname } from "next/navigation";
import { Globe } from "lucide-react";

export function LocaleSwitcher() {
  const locale = useLocale();
  const router = useRouter();
  const pathname = usePathname();

  const change = () => {
    const next = locale === "vi" ? "en" : "vi";
    const segments = pathname.split("/").filter(Boolean);
    if (["vi", "en"].includes(segments[0])) segments.shift();
    router.push(`/${next}/${segments.join("/")}`);
  };

  return (
    <button
      onClick={change}
      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg hover:bg-neutral-100 dark:hover:bg-neutral-800 text-sm"
    >
      <Globe className="w-4 h-4" />
      {locale.toUpperCase()}
    </button>
  );
}