"use client";

import { useQuery } from "@tanstack/react-query";
import { useEffect, useRef, useState } from "react";
import { WikiArticle } from "@/lib/types";

async function fetchArticles(): Promise<{ articles: WikiArticle[]; timestamp: string }> {
  const res = await fetch("/api/articles");
  if (!res.ok) throw new Error("Fetch failed");
  return res.json();
}

export function useArticlesRealtime() {
  const [newArticleIds, setNewArticleIds] = useState<Set<string>>(new Set());
  const prevIdsRef = useRef<Set<string>>(new Set());
  const [lastUpdate, setLastUpdate] = useState<Date>(new Date());

  const query = useQuery({
    queryKey: ["articles"],
    queryFn: fetchArticles,
    refetchInterval: 60_000,
    refetchIntervalInBackground: true,
    staleTime: 55_000,
    refetchOnWindowFocus: true,
  });

  useEffect(() => {
    if (!query.data?.articles) return;
    const currentIds = new Set(query.data.articles.map((a) => a.id));
    const newOnes = new Set<string>();
    currentIds.forEach((id) => {
      if (prevIdsRef.current.size > 0 && !prevIdsRef.current.has(id)) newOnes.add(id);
    });
    if (newOnes.size > 0) {
      setNewArticleIds(newOnes);
      setTimeout(() => setNewArticleIds(new Set()), 10_000);
    }
    prevIdsRef.current = currentIds;
    setLastUpdate(new Date());
  }, [query.data]);

  return { ...query, newArticleIds, lastUpdate };
}