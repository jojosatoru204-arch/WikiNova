import { NextResponse } from "next/server";
import { meili, ARTICLES_INDEX, ensureIndex } from "@/lib/meili";
import { slugify } from "@/lib/utils";

const CATEGORIES = [
  "Lịch sử", "Khoa học", "Văn hóa", "Công nghệ",
  "Nghệ thuật", "Địa lý", "Thể thao", "Giáo dục",
];

export async function POST() {
  await ensureIndex();

  const res = await fetch(
    "https://vi.wikipedia.org/w/api.php?" +
      new URLSearchParams({
        action: "query", format: "json", generator: "random",
        grnnamespace: "0", grnlimit: "100",
        prop: "extracts|pageimages|info", exintro: "1",
        explaintext: "1", exchars: "600", piprop: "thumbnail",
        pithumbsize: "400", inprop: "url", origin: "*",
      })
  );
  const data = await res.json();
  const pages = data?.query?.pages || {};

  const docs = Object.values(pages).map((p: any, i: number) => ({
    id: String(p.pageid),
    slug: slugify(p.title),
    title: p.title,
    extract: p.extract || "",
    thumbnail: p.thumbnail?.source || null,
    url: p.fullurl,
    category: CATEGORIES[i % CATEGORIES.length],
    views: Math.floor(Math.random() * 50000),
    updatedAt: Date.now(),
  }));

  await meili.index(ARTICLES_INDEX).addDocuments(docs);
  return NextResponse.json({ indexed: docs.length });
}