import { NextRequest, NextResponse } from "next/server";
import { meili, ARTICLES_INDEX } from "@/lib/meili";

export async function GET(req: NextRequest) {
  const q = req.nextUrl.searchParams.get("q")?.trim();
  const category = req.nextUrl.searchParams.get("category");

  if (!q || q.length < 2) return NextResponse.json({ results: [] });

  try {
    const result = await meili.index(ARTICLES_INDEX).search(q, {
      limit: 10,
      filter: category ? `category = "${category}"` : undefined,
      attributesToHighlight: ["title", "extract"],
      highlightPreTag: "<mark>",
      highlightPostTag: "</mark>",
    });
    return NextResponse.json({ results: result.hits });
  } catch {
    return NextResponse.json({ results: [] }, { status: 500 });
  }
}