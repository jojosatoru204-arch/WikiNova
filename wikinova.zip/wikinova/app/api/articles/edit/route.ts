import { NextRequest, NextResponse } from "next/server";
import { auth } from "@/lib/auth";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

export async function POST(req: NextRequest) {
  const session = await auth();
  if (!session?.user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { slug, title, content } = await req.json();
  const userId = (session.user as any).id;

  const article = await prisma.article.upsert({
    where: { slug },
    update: { title, content },
    create: { slug, title, content, category: "Khác", authorId: userId },
  });

  await prisma.revision.create({
    data: { articleId: article.id, content, editorId: userId },
  });

  return NextResponse.json({ ok: true, article });
}