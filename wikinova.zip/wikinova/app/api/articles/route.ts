import { NextResponse } from "next/server";
import { cacheGet, cacheSet } from "@/lib/redis";
import { slugify } from "@/lib/utils";

const CATEGORIES = [
  "Lịch sử", "Khoa học", "Văn hóa", "Công nghệ",
  "Nghệ thuật", "Địa lý", "Thể thao", "Giáo dục",
];

export async function GET() {
  const cached = await cacheGet<any>("articles:featured");
  if (cached) return NextResponse.json({ ...cached, fromCache: true });

  const res = await fetch(
    "https://vi.wikipedia.org/w/api.php?" +
      new URLSearchParams({
        action: "query", format: "json", generator: "random",
        grnnamespace: "0", grnlimit: "20",
        prop: "extracts|pageimages|info", exintro: "1",
        explaintext: "1", exchars: "400", piprop: "thumbnail",
        pithumbsize: "400", inprop: "url", origin: "*",
      })
  );
  const data = await res.json();
  const pages = data?.query?.pages || {};
  const articles = Object.values(pages).map((p: any, i: number) => ({
    id: String(p.pageid),
    slug: slugify(p.title),
    title: p.title,
    extract: p.extract || "Chưa có nội dung.",
    thumbnail: p.thumbnail?.source,
    url: p.fullurl,
    category: CATEGORIES[i % CATEGORIES.length],
    updatedAt: new Date().toISOString(),
    views: Math.floor(Math.random() * 50000) + 1000,
  }));

  const payload = {
    articles,
    timestamp: new Date().toISOString(),
    count: articles.length,
  };
  await cacheSet("articles:featured", payload, 55);
  return NextResponse.json(payload);
}