"use client";

import { useQuery } from "@tanstack/react-query";
import { useParams } from "next/navigation";
import { Sidebar } from "@/components/Sidebar";
import { TableOfContents } from "@/components/TableOfContents";
import { Comments } from "@/components/Comments";
import { OptimizedImage } from "@/components/OptimizedImage";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Edit, Share2, Bookmark, Volume2, Printer, ArrowUp } from "lucide-react";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { track } from "@/lib/track";

async function fetchArticle(slug: string) {
  const title = decodeURIComponent(slug).replace(/-/g, " ");
  const res = await fetch(
    `https://vi.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(title)}`
  );
  if (!res.ok) throw new Error("Not found");
  return res.json();
}

export default function ArticlePage() {
  const { slug } = useParams<{ slug: string }>();
  const { data, isLoading, error } = useQuery({
    queryKey: ["article", slug],
    queryFn: () => fetchArticle(slug),
    retry: 1,
  });
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const total = h.scrollHeight - h.clientHeight;
      setProgress((h.scrollTop / total) * 100);
    };
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    if (data?.title) track("article_view", { slug, title: data.title });
  }, [slug, data]);

  const readAloud = () => {
    if (!data?.extract) return;
    const u = new SpeechSynthesisUtterance(data.extract);
    u.lang = "vi-VN";
    speechSynthesis.speak(u);
    toast.info("Đang đọc bài viết...");
  };

  const share = async () => {
    await navigator.clipboard.writeText(window.location.href);
    toast.success("Đã copy link!");
  };

  if (error)
    return (
      <div className="p-8 text-center">
        <h1 className="text-2xl font-bold">Không tìm thấy bài viết</h1>
      </div>
    );

  return (
    <>
      <div
        className="fixed top-0 left-0 h-1 bg-gradient-to-r from-blue-600 to-purple-600 z-[60]"
        style={{ width: `${progress}%` }}
      />
      <div className="flex">
        <Sidebar />
        <main className="flex-1 min-w-0 max-w-7xl mx-auto px-4 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-[1fr_240px] gap-8">
            <article className="min-w-0">
              {isLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-12 w-3/4" />
                  <Skeleton className="h-4 w-1/2" />
                  <Skeleton className="h-64 w-full" />
                  <Skeleton className="h-4 w-full" />
                </div>
              ) : (
                <>
                  <h1 className="text-4xl md:text-5xl font-black mb-3">{data.title}</h1>
                  <p className="text-sm text-neutral-500 mb-6">
                    Cập nhật: {new Date(data.timestamp).toLocaleString("vi-VN")}
                  </p>

                  <div className="flex flex-wrap gap-2 mb-8 pb-6 border-b border-neutral-200 dark:border-neutral-800">
                    <Button variant="outline" size="sm">
                      <Edit className="w-4 h-4 mr-2" /> Chỉnh sửa
                    </Button>
                    <Button variant="outline" size="sm" onClick={share}>
                      <Share2 className="w-4 h-4 mr-2" /> Chia sẻ
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => toast.success("Đã lưu!")}>
                      <Bookmark className="w-4 h-4 mr-2" /> Lưu
                    </Button>
                    <Button variant="outline" size="sm" onClick={readAloud}>
                      <Volume2 className="w-4 h-4 mr-2" /> Đọc to
                    </Button>
                    <Button variant="outline" size="sm" onClick={() => window.print()}>
                      <Printer className="w-4 h-4 mr-2" /> In
                    </Button>
                  </div>

                  {data.thumbnail && (
                    <div className="mb-8 rounded-2xl overflow-hidden">
                      <OptimizedImage
                        src={data.thumbnail.source}
                        alt={data.title}
                        width={800}
                        height={500}
                        priority
                      />
                    </div>
                  )}

                  <div
                    className="prose prose-lg dark:prose-invert max-w-none"
                    dangerouslySetInnerHTML={{ __html: data.extract_html }}
                  />

                  <Comments term={slug} />
                </>
              )}
            </article>

            <aside className="hidden lg:block">
              <TableOfContents />
            </aside>
          </div>
        </main>
      </div>

      {progress > 20 && (
        <button
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="fixed bottom-6 left-6 w-12 h-12 rounded-full bg-white dark:bg-neutral-900 border border-neutral-200 dark:border-neutral-800 shadow-xl grid place-items-center z-40"
        >
          <ArrowUp className="w-5 h-5" />
        </button>
      )}
    </>
  );
}