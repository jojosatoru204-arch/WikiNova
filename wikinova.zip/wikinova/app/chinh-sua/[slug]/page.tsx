"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Editor } from "@/components/Editor";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { toast } from "sonner";
import { Save, ArrowLeft } from "lucide-react";

export default function EditPage({ params }: { params: { slug: string } }) {
  const [title, setTitle] = useState(decodeURIComponent(params.slug).replace(/-/g, " "));
  const [content, setContent] = useState("");
  const [saving, setSaving] = useState(false);
  const router = useRouter();

  const save = async () => {
    setSaving(true);
    try {
      const res = await fetch("/api/articles/edit", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ slug: params.slug, title, content }),
      });
      if (!res.ok) throw new Error();
      toast.success("Đã lưu bài viết!");
      router.push(`/bai-viet/${params.slug}`);
    } catch {
      toast.error("Lưu thất bại. Vui lòng đăng nhập.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <Button variant="ghost" onClick={() => router.back()} className="mb-4">
        <ArrowLeft className="w-4 h-4 mr-2" /> Quay lại
      </Button>
      <Input
        value={title}
        onChange={(e) => setTitle(e.target.value)}
        className="text-2xl font-bold mb-4 h-14"
      />
      <Editor content={content} onChange={setContent} />
      <div className="flex justify-end gap-2 mt-4">
        <Button variant="outline" onClick={() => router.back()}>Hủy</Button>
        <Button
          onClick={save}
          disabled={saving}
          className="bg-gradient-to-r from-blue-600 to-purple-600"
        >
          <Save className="w-4 h-4 mr-2" />
          {saving ? "Đang lưu..." : "Lưu thay đổi"}
        </Button>
      </div>
    </div>
  );
}