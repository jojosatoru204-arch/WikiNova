export default function OfflinePage() {
  return (
    <div className="min-h-screen grid place-items-center px-4 text-center">
      <div>
        <h1 className="text-4xl font-bold mb-2">📡 Bạn đang offline</h1>
        <p className="text-neutral-500 mb-6">
          Một số bài viết đã đọc trước đó vẫn có thể truy cập được.
        </p>
        <a href="/" className="inline-block px-6 py-3 rounded-xl bg-blue-600 text-white">
          Thử lại
        </a>
      </div>
    </div>
  );
}