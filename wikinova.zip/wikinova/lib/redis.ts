import { Redis } from "@upstash/redis";

export const redis = new Redis({
  url: process.env.UPSTASH_REDIS_REST_URL!,
  token: process.env.UPSTASH_REDIS_REST_TOKEN!,
});

export async function cacheGet<T>(key: string): Promise<T | null> {
  return (await redis.get<T>(key)) ?? null;
}

export async function cacheSet(key: string, val: any, ttlSeconds = 60) {
  await redis.set(key, val, { ex: ttlSeconds });
}