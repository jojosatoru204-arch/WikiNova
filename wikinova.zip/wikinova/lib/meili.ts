import { MeiliSearch } from "meilisearch";

export const meili = new MeiliSearch({
  host: process.env.MEILISEARCH_HOST!,
  apiKey: process.env.MEILISEARCH_KEY,
});

export const ARTICLES_INDEX = "articles";

export async function ensureIndex() {
  const indexes = await meili.getIndexes();
  if (!indexes.results.find((i) => i.uid === ARTICLES_INDEX)) {
    await meili.createIndex(ARTICLES_INDEX, { primaryKey: "id" });
    await meili.index(ARTICLES_INDEX).updateSettings({
      searchableAttributes: ["title", "extract", "category"],
      filterableAttributes: ["category"],
      sortableAttributes: ["views", "updatedAt"],
      rankingRules: ["words", "typo", "proximity", "attribute", "sort", "exactness"],
    });
  }
}