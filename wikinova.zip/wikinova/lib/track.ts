declare global {
  interface Window { umami?: { track: (e: string, d?: any) => void } }
}

export const track = (event: string, data?: Record<string, any>) => {
  if (typeof window !== "undefined" && window.umami) {
    window.umami.track(event, data);
  }
};