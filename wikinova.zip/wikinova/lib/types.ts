export interface WikiArticle {
  id: string;
  slug: string;
  title: string;
  extract: string;
  thumbnail?: string;
  url: string;
  category: string;
  updatedAt: string;
  views: number;
  hasUpdate?: boolean;
}

export interface WikiUpdate {
  articles: WikiArticle[];
  timestamp: string;
  count: number;
}